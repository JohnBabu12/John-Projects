#include<lpc21xx.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include"i2c_defines.h"
#include"delay.h"
#include"keypad.h"
#include"lcd.h"
#include"uart0.h"
#include"i2c.h"
#include"i2c_eeprom.h"
#include"types.h"
#include"Lcd_macro.h"
#include"defines.h"
void UART0_Str(u8 *);  
void funpancard(void);
void funatmcard	(void);
void fundrivinglicense(void);
void funvotingcard(void);
void rtc_init(void);
void InitUART0(void); 
extern u8 buff[11];
extern u8 i;
const u8 prolut[]={0X0E,0X11,0X11,0X1F,0X11,0X11,0X0A,0X04,0X1F,0X1F,0X1F,0X1F,0X10,0X10,0X10,0X10,0X00,0X04,0X02,0X1F,0X02,0X04,0X00,0X00,0X0F,0X0F,0X10,0X10,0X0F,0X0F,0X00};
u16 n;
u8 kpmlut[4][4]={{'1','2','3','4'},{'5','6','7','8'},{'9','0','*','#'},{'!','@','$','&'}}; 
const u16 date=1;
const u16 month=1;
const u16 year=2026;
u8 ptr[20],*p;
u8* Read_num(void)
{
	u8 k=0;
	static u8 str[10];
	do
	{
		str[k]=keyscan();
	}while(str[k++]!='*');
	str[--k]='\0';
	return str;
}		
void menu(void)
{
		char ch;
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("1.PAN CARD");
		Cmd_lcd(GOTO_LINE2_POS0);
		Str_lcd("2.ATM CARD");
		Cmd_lcd(GOTO_LINE3_POS0);
		Str_lcd("3.VOTING CARD");
		Cmd_lcd(GOTO_LINE4_POS0);
		Str_lcd("4.Driving license");
		Cmd_lcd(GOTO_LINE1_POS0+13);
		Str_lcd("5.EXIT");
		ch=keyscan();
	    Cmd_lcd(CLEAR_LCD);
		switch(ch)
		{
			case '1': funpancard();
					  break;
			case '2': funatmcard();
					  break;
			case '3': funvotingcard();
					  break;
			case '4': fundrivinglicense();
					  break;
			case '5':exit(0);
		} 
}
void balenq(void)
{	int n1,n2;
	Cmd_lcd(CLEAR_LCD);
	n1=i2c_eeprom_read(0x50,45);
	n2=i2c_eeprom_read(0x50,46);
	n=n1|n2;
	Cmd_lcd(GOTO_LINE1_POS0);
	Itoa_lcd(n);
}
void withdraw(void)
{
	u8 *ch;
	u16 a,n1,n2,b;
	if(n>500)
	{
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("enter the amount");
	ch=Read_num();
	a=atoi((const char*)ch);
	n1=i2c_eeprom_read(0x50,45);
	n2=i2c_eeprom_read(0x50,46);
	b=n1|n2;
	if(a<b)
	{
		n=a-b;
		i2c_eeprom_write(0x50,45,n);
		i2c_eeprom_write(0x50,46,n<<8);
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("WITHDRAWN SUCCESS");
		delay_s(2);
		Cmd_lcd(CLEAR_LCD);
		menu();
	}
	}
	else
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("INSUFFICIENT AMOUNT");
		delay_s(2);
		Cmd_lcd(CLEAR_LCD);
	}
}
void deposit(void)
{
	//u8 *p;
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("ENTER AMOUNT");
	p=Read_num();
	Cmd_lcd(CLEAR_LCD);
	Str_lcd("SUCCESSFULL");
	delay_s(2);
	Cmd_lcd(CLEAR_LCD);
	menu();
}
void funvotingcard(void)
{
	u8 ch;
	i2c_eeprom_seq_read(0x50,50,ptr,2);
	if(strcmp("NV",(const char *)ptr)==0)
	{
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("NOT VOTED");
		Cmd_lcd(GOTO_LINE2_POS0);
		Str_lcd("CAST YOUR VOTE");
		delay_s(1);
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("PARTY 1");
		Cmd_lcd(GOTO_LINE1_POS0+9);
		Char_lcd(0);
		Cmd_lcd(GOTO_LINE2_POS0);
		Str_lcd("PARTY 2");
		Cmd_lcd(GOTO_LINE2_POS0+9);
		Char_lcd(1);
		Cmd_lcd(GOTO_LINE3_POS0);
		Str_lcd("PARTY 3");
		Cmd_lcd(GOTO_LINE3_POS0+9);
		Char_lcd(2);
		Cmd_lcd(GOTO_LINE4_POS0);
		Str_lcd("PARTY 4");
		Cmd_lcd(GOTO_LINE4_POS0+9);
		Char_lcd(3);
		ch=keyscan();
		Cmd_lcd(CLEAR_LCD);
		switch(ch)
		{
			case '1':i2c_eeprom_page_write(0x50,50,"V1",2);
					 break;
			case '2':i2c_eeprom_page_write(0x50,50,"V2",2);
					 break;
			case '3':i2c_eeprom_page_write(0x50,50,"V3",2);
					 break;
			case '4':i2c_eeprom_page_write(0x50,50,"V4",2);
					 break;
		}
	}
	else
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("ALREADY VOTED");
		delay_s(2);
		Cmd_lcd(CLEAR_LCD);
		menu();
		
	}
}
void fundrivinglicense(void)
{
	
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("sai kiran reddy");
	Cmd_lcd(GOTO_LINE2_POS0);
	Str_lcd("TWO WHEELER");
	if(year>YEAR)
	{
		Cmd_lcd(GOTO_LINE3_POS0);
		Str_lcd("LICENSE VALID");
	}
	else if(YEAR==year)
	{
		if(month>MONTH)
		{
			Cmd_lcd(GOTO_LINE3_POS0);
			Str_lcd("LICENSE VALID");
		}	
		else if(month==MONTH)
		{
			if(date>=DOM)
			{
			Cmd_lcd(0X94);
			Str_lcd("VAILD LICENSE");		
			}
			else
			{
				Cmd_lcd(0X94);
				Str_lcd("INVAILD LICENSE");
			}
				
		}
	}
	else
	{
		Cmd_lcd(GOTO_LINE3_POS0);
		Str_lcd("LICENSE INVALID");
	}
	Cmd_lcd(GOTO_LINE4_POS0);
	Str_lcd("REDLABAZAR GUNTUR");
	delay_s(2);
	Cmd_lcd(CLEAR_LCD);
	menu();
}
void funpancard(void)
{
	int n;
	u8* p;
	pass:
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("ENTER THE PASSWORD");
	p=Read_num();
	Str_lcd(p);
	n=atoi((const char*)p);
	if(n==9059)
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		i2c_eeprom_seq_read(0x50,0,ptr,9);
		Str_lcd(ptr);
		Cmd_lcd(GOTO_LINE2_POS0);
		i2c_eeprom_seq_read(0x50,15,ptr,10);
		Str_lcd(ptr);
		Cmd_lcd(GOTO_LINE3_POS0);
		i2c_eeprom_seq_read(0x50,30,ptr,10);
		Str_lcd(ptr);
		delay_s(5);
		Cmd_lcd(CLEAR_LCD);
		menu();
	}
	else
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("invalid password");
		delay_s(2);
		goto pass;
	}
}
void funatmcard(void)
{
	u8 *p,ch;
	int n;
	bal:
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("ENTER THE PASSWORD");
	p=Read_num();
	n=atoi((const char*)p);
	if(n==9059)
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("1.Bal enquiry");
		Cmd_lcd(GOTO_LINE2_POS0);
		Str_lcd("2.With drawn");
		Cmd_lcd(GOTO_LINE3_POS0);
		Str_lcd("3.Deposit");
		Cmd_lcd(GOTO_LINE4_POS0);
		Str_lcd("4.exit");
		ch=keyscan();
		Cmd_lcd(CLEAR_LCD);
		switch(ch)
		{
		case '1': balenq();
				  break;
		case '2': withdraw();
				  break;
		case '3': deposit();
				  break;
		case '4': menu();
		}
	}
	else
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("invalid password");
		goto bal;
	}

}
main()
{
	INIT_lcd();
	Init_kpm();
	init_i2c();
	rtc_init();
	InitUART0();
	Build_CG_ram((u8*)prolut,32);
	//PAN CARD STORAGE
	i2c_eeprom_page_write(0x50,0,"sai kiran",9);
	i2c_eeprom_page_write(0x50,15,"05/01/2024",10);
	i2c_eeprom_page_write(0x50,30,"ABK00KU967",10);
	//ATM CARD BALANCE ENQUIRY STORAGE
	n=5500;
	i2c_eeprom_write(0x50,45,n);
	i2c_eeprom_write(0x50,46,n<<8);
	//VOTING
	i2c_eeprom_page_write(0x50,50,"NV",2);



	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("MULTI PURPOSE E-CARD SYSTEM");
	delay_s(3);
	Cmd_lcd(CLEAR_LCD);
	Cmd_lcd(GOTO_LINE1_POS0);
	Str_lcd("Waiting for the card");
	i=0;
	UART0_Str("Waiting for the card");
	while(i<9);
	if(strcmp((const char *)buff+1,"12345678")==0)
	{
		UART0_Str(buff);
		menu();
	}
	else if(strcmp((const char*)buff+1,"23456789")==0)
	{
		menu();
	}

	else
	{
		Cmd_lcd(CLEAR_LCD);
		Cmd_lcd(GOTO_LINE1_POS0);
		Str_lcd("Invalid card");
		delay_s(2);
		Cmd_lcd(CLEAR_LCD);
		menu();
		
	}
while(1);

}		
		
